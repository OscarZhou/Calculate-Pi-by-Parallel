// Coding by Oscar
//
//
//


#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <ctime>

// Global variables
long a = 1664525;
long m = 4294967296;
long c = 1013904223;

/*
 * Method: Generate the random number sequencially
 * formula: x(i+1) = (a * xi + c) mod m
 * Variable DEscription:
 */

double generateAndCalculatePiInSequence(int seed, int length)
{

	double sumf = 0;
	long i_prev = seed;
	long i_next = 0;
	for (int i =0; i< length;++i)
	{
		i_next = (a * i_prev + c) % m;
		double x_rand = float(i_next) / (m -1 );
		i_prev = i_next;
		double fx = sqrt(1 - x_rand * x_rand);
		sumf += fx;
	}
	double area = sumf / length;
	double pi_calc = 4 * area;
	return pi_calc;
}


int main(int argc, char* argv[])
{
	double result = 0;
	int initial_seed = 12345;
	long length = atol(argv[1]);

	long t_start = clock();
	//int t_start = GetTickCount();
	std::cout << "---------------t_start  = "<<t_start <<"--------------\n"<<std::endl;
	result = generateAndCalculatePiInSequence(initial_seed, length);
	long t_end = clock();
	//int t_end = GetTickCount();
	std::cout << "---------------t_end  = "<<t_end <<"--------------\n"<<std::endl;

	std::cout << "The time of calculating is "<< (t_end - t_start)/double(CLOCKS_PER_SEC)<<std::endl;
	std::cout << "The pi calculated by "<<length<<" random numbers is "<<result<<" in sequentially"<<std::endl;
	return 0;
}
