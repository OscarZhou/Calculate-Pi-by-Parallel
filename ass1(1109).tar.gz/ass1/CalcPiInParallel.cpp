// Coding by Oscar

#include "mpi.h"
#include "math.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctime>

// Global variables
long a = 1664525;
long m = 4294967296;
long c = 1013904223;

/*
Method: Modulo exponentiation
Formula : x**n mod p
*/
long calExpo(long x, long n, long p)
{
    long y = 1;
    for (int i = 0; i < n; ++i)
    {
        y = (y*x) % p;
    }
    return y;
}


/*
Method: Calculate the constant A used for frog leaping
Formula: A = a**k mod m
*/
long calA(long a, int k, long m)
{
    return calExpo(a, k, m);
}



/*
Method: Calculate the constant C used for frog leaping
Formula: C = c*(a**(k-1) + a**(k-2) +.....+ a**1 + a**0) mod m
*/
long calC(long a, int k, long m)
{
    long sumf = 0;
    for (int i = k; i >= 0; --i)
    {
        sumf += calExpo(a, i, m);
    }
    long res = (c * (sumf % m)) % m;
    return res;
}

/*
Method: Generate the random number in parallel evironment
Formula: x(i+k) = (A * xi + C) mod m
Variable Desciption:
world_size: the numbers of process
length: the total length of random number calculated
processorNo: the index of processor
*/

double generateAndCRandomNumInParallel(int seed, int world_size, int length, int processorNo)
{
    double sumf = 0;
    long i_prev = seed; // assign a seed
    long A = calA(a, world_size, m);
    long C = calC(a, world_size, m);
    for (int i = processorNo; i < length - world_size; i = i + world_size)
    {
        long i_next = (A * i_prev + C) % m;
        double x_rand = float(i_next) / (m - 1); // Scale to a float in the range 0-1
        i_prev = i_next;
        double fx = sqrt(1 - x_rand * x_rand);
        sumf += fx;
    }
    double area = sumf / ((length - world_size)/ world_size);
    double pi_calc = 4 * area;
    return pi_calc;
}


/*
Method: Generate the random number sequencially
Formula: x(i+1) = (a * xi + c) mod m
Variable Desciption:
world_size: the numbers of process
length: the total length of random number calculated
array[]: output parameters which is used for saving the random numbers generated lately
*/

long* generateRandomNumInSequence(int seed, int length)
{
    long *sequenceSeed = new long[length];
    double sumf = 0;
    long i_prev = seed;
    long i_next = 0;
    for (int i = 0; i < length;++i)
    {
        i_next = (a * i_prev + c) % m; // Next Random integer in the sequence
        sequenceSeed[i] = i_next;
        i_prev = i_next;
    }
    return sequenceSeed;
}



int main(int argc, char *argv[])
{
    double t_start, t_start_p1, t_start_p2, t_end;
    
    //fprintf(stdout, "---------------The start time of total time of serial execution is %f--------------\n", t_start);
    double result=0;
    double ret0=0, ret1=0;
    long length = atol(argv[1]);
    int world_size;
    int rank;
    

    MPI_Status Stat;// status variable, so operations can be checked
    MPI_Init(&argc, &argv);
    t_start = MPI_Wtime();
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    fprintf(stdout, "world_size  = %d\n", world_size);

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    // Firstly, generate the seed for other processors with leapfrog

    if (rank == 0)
    {
        // 1.Generate seeds of corresponding numbers with the numbers of processors
        fprintf(stdout, "processor %d is running\n", rank);
        long *arraySeed = new long[world_size];
        arraySeed = generateRandomNumInSequence(12345, world_size);

        fprintf(stdout, "seed[0]=%ld\n", arraySeed[0]);
        // 2. Master sends seed to all the slave processes
        for (int i = 1; i < world_size; i++)
        {
            fprintf(stdout, "seed[%d]=%ld\n", i, arraySeed[i]);
            MPI_Send(&arraySeed[i], 1, MPI_LONG, i, 0, MPI_COMM_WORLD);
        }

        // 3. Master calculates its own partial pi
        ret0 = generateAndCRandomNumInParallel(arraySeed[0], world_size, length, rank );
        fprintf(stdout, "ret%d=%ld\n", rank, ret0);

        result += ret0;

	t_start_p2 = MPI_Wtime();
        // 7. Receive nodes from all nodes
        for (int i = 1; i < world_size; i++)
        {
            MPI_Recv(&ret1, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &Stat);
            result += ret1;
        //	fprintf(stdout, "node=%ld: result=%.4f: ret1=%.4f\n", i, result, ret1);

        }
        result = result / world_size;
        fprintf(stdout, "The pi calculated by %ld random numbers is %.10f \n", length, result);

    	t_end = MPI_Wtime();

    	fprintf(stdout, "Total time of parallelizing is %f \n ", (t_end - t_start));
    }
    else // this is not the master
    {

        fprintf(stdout, "processor %d is running\n", rank);

        long slaveseed;
        // 4. slave processor wait for receiving the original seed
        MPI_Recv(&slaveseed,1 , MPI_LONG, 0, 0, MPI_COMM_WORLD, &Stat);
	
	t_start_p1 = MPI_Wtime();

        // 5. slave processor calculate their own pi
        ret1 = generateAndCRandomNumInParallel(slaveseed, world_size, length,  rank);
        fprintf(stdout, "ret%d=%f\n", rank, ret1);
        // 6. slave processor send the pi value back to master processor
        MPI_Send(&ret1, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }
    
    //t_end = MPI_Wtime();
    MPI_Finalize();

    //fprintf(stdout, "Total time of parallelizing is %f \n ", (t_end - t_start));
    //fprintf(stdout, "time of serial part 1 is %f \n ", (t_start_p1 - t_start));
    //fprintf(stdout, "time of serial part 2 is %f \n ", (t_end - t_start_p2));
    fflush(stdout);
    return 0;
}


